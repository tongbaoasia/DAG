A Typescript implementation of itc.

## Project Stage

Pre-alpha, a try-out of Typescript on blockchain, still under active development.
Any implementation details may be rapidly changed without prior notice.

## Documentation

TBD

## License

MIT.
