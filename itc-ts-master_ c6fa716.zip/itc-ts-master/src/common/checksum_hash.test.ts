import {getChash160} from './checksum_hash';

test('test checksum hash', () => {
    console.log(getChash160('oho'));
});

