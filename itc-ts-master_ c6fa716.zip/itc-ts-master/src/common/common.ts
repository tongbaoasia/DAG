type Address = string;
type DeviceAddress = string;
type PubKey = string;
type DevicePrivKey = Buffer;
type DevicePubKey = string;
type Hex = string;
type Base64 = string;
