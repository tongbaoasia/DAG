import * as pino from 'pino';

const logger = pino({prettyPrint: true});
export default logger;
