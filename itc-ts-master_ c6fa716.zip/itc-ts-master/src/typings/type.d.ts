declare module 'secp256k1';
declare module 'bitcore-lib';
declare module 'bitcore-mnemonic';
declare module 'websocket-as-promised';
