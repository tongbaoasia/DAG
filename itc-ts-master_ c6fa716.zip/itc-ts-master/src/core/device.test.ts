import {Device} from './device';

test('test device', () => {
    const device1 = new Device();
    const device2 = new Device();

    console.log(device1);
    console.log(device2);
});
