/**
* Copyright (c) 2018 Zilliqa 
* This source code is being disclosed to you solely for the purpose of your participation in 
* testing Zilliqa. You may view, compile and run the code for that purpose and pursuant to 
* the protocols and algorithms that are programmed into, and intended by, the code. You may 
* not do anything else with the code without express permission from Zilliqa Research Pte. Ltd., 
* including modifying or publishing the code (or any part of it), and developing or forming 
* another public or private blockchain network. This source code is provided ‘as is’ and no 
* warranties are given as to title or non-infringement, merchantability or fitness for purpose 
* and, to the extent permitted by law, all liability for your use of the code is disclaimed. 
* Some programs in this code are governed by the GNU General Public License v3.0 (available at 
* https://www.gnu.org/licenses/gpl-3.0.en.html) (‘GPLv3’). The programs that are governed by 
* GPLv3.0 are those programs that are located in the folders src/depends and tests/depends 
* and which include a reference to GPLv3 in their program files.
**/

#include <arpa/inet.h>
#include <array>
#include <string>
#include <thread>
#include <vector>

#include "common/Messages.h"
#include "common/Serializable.h"
#include "common/Constants.h"
#include "libCrypto/Schnorr.h"
#include "libData/AccountData/Address.h"
#include "libData/BlockData/Block.h"
#include "libData/AccountData/Transaction.h"
#include "libNetwork/P2PComm.h"
#include "libUtils/TimeUtils.h"

#define BOOST_TEST_MODULE lookupnodetxblocktest
#include <boost/test/included/unit_test.hpp>

#include <boost/multiprecision/cpp_int.hpp>

using namespace std;
using namespace boost::multiprecision;

BOOST_AUTO_TEST_SUITE (lookupnodetxblocktest)

void SendDSBlockFirstToMatchDSBlockNum(Peer & lookup_node)
{
    LOG_MARKER();

    vector<unsigned char> dsblockmsg = { MessageType::NODE, NodeInstructionType::DSBLOCK };
    unsigned int curr_offset = MessageOffset::BODY;

    BlockHash prevHash1;

    for (unsigned int i = 0; i < prevHash1.asArray().size(); i++)
    {
        prevHash1.asArray().at(i) = i + 1;
    }

    std::array<unsigned char, BLOCK_SIG_SIZE> signature1;

    for (unsigned int i = 0; i < signature1.size(); i++)
    {
        signature1.at(i) = i + 8;
    }

    std::pair<PrivKey, PubKey> pubKey1 = Schnorr::GetInstance().GenKeyPair();
 
    DSBlockHeader header1(20, prevHash1, 12344, pubKey1.first, pubKey1.second, 0, 789);

    DSBlock dsblock(header1, signature1);

    curr_offset += dsblock.Serialize(dsblockmsg, curr_offset);

    dsblockmsg.resize(curr_offset + 32);
    Serializable::SetNumber<uint256_t>(dsblockmsg, curr_offset, 0, UINT256_SIZE);
    curr_offset += UINT256_SIZE;

    struct sockaddr_in localhost;
    inet_aton("127.0.0.1", &localhost.sin_addr);

    dsblockmsg.resize(curr_offset + 16);
    Serializable::SetNumber<uint128_t>(dsblockmsg, curr_offset, 
                                      (uint128_t)localhost.sin_addr.s_addr, UINT128_SIZE);
    curr_offset += UINT128_SIZE;

    dsblockmsg.resize(curr_offset + 4);
    Serializable::SetNumber<uint32_t>(dsblockmsg, curr_offset, (uint32_t)5001, 4);
    curr_offset += 4;

    P2PComm::GetInstance().SendMessage(lookup_node, dsblockmsg);    
}

BOOST_AUTO_TEST_CASE (testTxBlockStoring)
{
    INIT_STDOUT_LOGGER();

    LOG_MARKER();

    uint32_t listen_port = 5000; 
    struct in_addr ip_addr;
    inet_aton("127.0.0.1", &ip_addr);
    Peer lookup_node((uint128_t)ip_addr.s_addr, listen_port);

    SendDSBlockFirstToMatchDSBlockNum(lookup_node);

    vector<unsigned char> txblockmsg = { MessageType::NODE, NodeInstructionType::FINALBLOCK };
    unsigned int curr_offset = MessageOffset::BODY;

    // 32-byte DS blocknum
    Serializable::SetNumber<uint256_t>(txblockmsg, curr_offset, 0, sizeof(uint256_t));
    curr_offset += sizeof(uint256_t);

    // 4-byte consensusid
    Serializable::SetNumber<uint32_t>(txblockmsg, curr_offset, 0, sizeof(uint32_t));
    curr_offset += sizeof(uint32_t);

    // shard-id
    txblockmsg.resize(curr_offset + 1);
    Serializable::SetNumber<uint8_t>(txblockmsg, curr_offset, (uint8_t) 0, 1);
    curr_offset += 1;

    // std::array<unsigned char, TRAN_HASH_SIZE> emptyHash = {0};

    std::pair<PrivKey, PubKey> pubKey1 = Schnorr::GetInstance().GenKeyPair();

    TxBlockHeader header(TXBLOCKTYPE::FINAL, BLOCKVERSION::VERSION1, 1, 1, BlockHash(), 0, 
                            get_time_as_int(), TxnHash(), StateHash(), 0, 5, pubKey1.second, 0, BlockHash());
    
    array<unsigned char, BLOCK_SIG_SIZE> emptySig = { 0 };

    std::vector<TxnHash> tranHashes;

    for(int i=0; i<5; i++)
    {
        tranHashes.push_back(TxnHash());
    }

    TxBlock txblock(header, emptySig, vector<bool>(), tranHashes);

    curr_offset += txblock.Serialize(txblockmsg, curr_offset);

    P2PComm::GetInstance().SendMessage(lookup_node, txblockmsg);
}

BOOST_AUTO_TEST_CASE (testTxBlockRetrieval)
{
    INIT_STDOUT_LOGGER();

    LOG_MARKER();
    
    long long i = 0;
    for(; i<1000000000; i++) {;}
    LOG_MESSAGE(i);

    uint32_t listen_port = 5000; 
    struct in_addr ip_addr;
    inet_aton("127.0.0.1", &ip_addr);
    Peer lookup_node((uint128_t)ip_addr.s_addr, listen_port);

    vector<unsigned char> getTxBlockMessage = { MessageType::LOOKUP, 
                                                LookupInstructionType::GETTXBLOCKFROMSEED };
    unsigned int curr_offset = MessageOffset::BODY;

    Serializable::SetNumber<uint256_t>(getTxBlockMessage, curr_offset, 
                                       0, UINT256_SIZE);
    curr_offset += UINT256_SIZE;

    Serializable::SetNumber<uint256_t>(getTxBlockMessage, curr_offset, 
                                       1, UINT256_SIZE);
    curr_offset += UINT256_SIZE;

    Serializable::SetNumber<uint32_t>(getTxBlockMessage, curr_offset, 
                                      5000, sizeof(uint32_t));
    curr_offset += sizeof(uint32_t);

    P2PComm::GetInstance().SendMessage(lookup_node, getTxBlockMessage);
}

BOOST_AUTO_TEST_SUITE_END ()