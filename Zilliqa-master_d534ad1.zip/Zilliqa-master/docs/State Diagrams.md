# State Diagrams

## DirectoryService
![DirectoryService State Diagram](images/DirectoryService.jpg "DirectoryService State Diagram")

## Node

![Node State Diagram](images/Node.jpg "Node State Diagram")

## Consensus

![Consensus State Diagram](images/Consensus.jpg "Consensus State Diagram")
