/**
* Copyright (c) 2018 Zilliqa 
* This is an alpha (internal) release and is not suitable for production.
**/


#ifndef __TRIE_H__
#define __TRIE_H__

class Trie
{
};

#endif // __TRIE_H__
