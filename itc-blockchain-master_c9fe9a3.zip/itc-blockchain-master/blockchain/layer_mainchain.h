#pragma once

//include
#include "layer.h"
//define

//typedef
//struct
//function
uint8 process_mainchain(void);
