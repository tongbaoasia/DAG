#pragma once

//include
#include "layer_device.h"
#include "layer_dag.h"
//define
//typedef
//struct
//function
